package com.example.equationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EquationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EquationServiceApplication.class, args);
	}

}
