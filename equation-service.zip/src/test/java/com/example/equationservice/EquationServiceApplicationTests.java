package com.example.equationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EquationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
